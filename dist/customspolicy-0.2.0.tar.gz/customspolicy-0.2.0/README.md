# Example Package

This package allows Schengen tourists to check the ability to stay/visit in Schengen countries when they have 180 visa restricting 90 days stay.