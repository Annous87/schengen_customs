# -*-coding:utf-8 -*-
  
# info
__author__ = 'Anass ALHYAR'
__status__ = 'Prototype'
__date__ = '10-Jan-19'
